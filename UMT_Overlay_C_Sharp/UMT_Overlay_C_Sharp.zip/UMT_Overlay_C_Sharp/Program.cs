﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Threading.Tasks;

public class OverlayForm : Form
{
    Timer timer = new Timer();
    Timer countCheckTimer = new Timer();
    Timer signOutCheckTimer = new Timer();

    Process targetProcess;

    int lastCount = -1;
    int lastSignOutCount = -1;
    bool buttonsLoaded = false;

    const int LEFT_X = 0;

    const int NBT_Y = 38;
    const int CONVERTER_Y = 102;
    const int PRUNER_Y = 166;
    const int EXTENSIONS_Y = 478;
    const int SETTINGS_Y = 542;
    const int SIGNOUT_Y = 606;

    const int NO_BUTTON_X = 886;
    const int MINIMIZE_X = 924;

    // Main buttons
    PictureBox nbtButton = new PictureBox();
    PictureBox converterButton = new PictureBox();
    PictureBox prunerButton = new PictureBox();
    PictureBox extensionsButton = new PictureBox();
    PictureBox settingsButton = new PictureBox();
    PictureBox signOutButton = new PictureBox();

    PictureBox noButton = new PictureBox();
    PictureBox minimizeButton = new PictureBox();

    // Converter Option
    PictureBox converterOptionButton = new PictureBox();
    PictureBox converterHoverText = new PictureBox();

    // Pruner Option
    PictureBox prunerOptionButton = new PictureBox();
    PictureBox prunerHoverText = new PictureBox();

    // NBT Option
    PictureBox nbtOptionButton = new PictureBox();
    PictureBox nbtHoverText = new PictureBox();

    // Images
    Image nbtNormal, nbtHover;
    Image converterNormal, converterHover;
    Image prunerNormal, prunerHover;
    Image extensionsNormal, extensionsHover;
    Image settingsNormal, settingsHover;
    Image signOutNormal, signOutHover;

    Image noButtonImg;

    Image minimizeNormal;
    Image minimizeHover;
    Image minimizeClick;

    // Converter images
    Image converterOptionNormal;
    Image converterOptionHover;
    Image converterTextImage;

    // Pruner images
    Image prunerOptionNormal;
    Image prunerOptionHover;
    Image prunerTextImage;

    // NBT images
    Image nbtOptionNormal;
    Image nbtOptionHover;
    Image nbtTextImage;

    [DllImport("user32.dll")]
    static extern bool GetWindowRect(IntPtr hwnd, out RECT rect);

    [DllImport("user32.dll")]
    static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

    [DllImport("user32.dll")]
    static extern int GetWindowLong(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll")]
    static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

    [DllImport("user32.dll")]
    static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    const int SW_MINIMIZE = 6;

    const int GWL_STYLE = -16;
    const int WS_MAXIMIZEBOX = 0x10000;
    const int WS_SIZEBOX = 0x40000;

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    public OverlayForm(Process process)
    {
        targetProcess = process;

        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        ShowInTaskbar = false;

        BackColor = Color.Lime;
        TransparencyKey = Color.Lime;

        SetParent(this.Handle, targetProcess.MainWindowHandle);

        DisableResize();

        timer.Interval = 20;
        timer.Tick += TrackPosition;
        timer.Start();

        LoadImages();

        // Main buttons
        SetupButton(nbtButton, nbtNormal, nbtHover, 70, 64);
        SetupButton(converterButton, converterNormal, converterHover, 70, 64);
        SetupButton(prunerButton, prunerNormal, prunerHover, 70, 64);
        SetupButton(extensionsButton, extensionsNormal, extensionsHover, 70, 64);
        SetupButton(settingsButton, settingsNormal, settingsHover, 70, 64);
        SetupButton(signOutButton, signOutNormal, signOutHover, 70, 64);

        SetupNoButton();
        SetupMinimizeButton();

        // Option buttons
        SetupConverterOptionButton();
        SetupConverterHoverText();

        SetupPrunerOptionButton();
        SetupPrunerHoverText();

        SetupNBTOptionButton();
        SetupNBTHoverText();

        // Count check every 1s
        countCheckTimer.Interval = 500;
        countCheckTimer.Tick += CheckCount;
        countCheckTimer.Start();

        // Sign_Out_Count.txt check every 2s
        signOutCheckTimer.Interval = 1500;
        signOutCheckTimer.Tick += CheckSignOutCount;
        signOutCheckTimer.Start();
    }

    void DisableResize()
    {
        IntPtr hwnd = targetProcess.MainWindowHandle;

        int style = GetWindowLong(hwnd, GWL_STYLE);
        style &= ~WS_MAXIMIZEBOX;
        style &= ~WS_SIZEBOX;

        SetWindowLong(hwnd, GWL_STYLE, style);
    }

    async void CheckCount(object sender, EventArgs e)
    {
        if (buttonsLoaded) return;

        try
        {
            using (WebClient wc = new WebClient())
            {
                string text = await wc.DownloadStringTaskAsync("http://localhost/UMT_Minecraft_Cracked/Count.txt");
                text = text.Trim();

                if (int.TryParse(text, out int newCount))
                {
                    if (lastCount == -1)
                    {
                        lastCount = newCount;
                        return;
                    }

                    if (newCount == lastCount + 1)
                    {
                        buttonsLoaded = true;
                        lastCount = newCount;

                        await Task.Delay(1200);

                        // Show all buttons simultaneously
                        converterOptionButton.Visible = true;
                        prunerOptionButton.Visible = true;
                        nbtOptionButton.Visible = true;
                    }
                }
            }
        }
        catch { }
    }

    async void CheckSignOutCount(object sender, EventArgs e)
    {
        try
        {
            using (WebClient wc = new WebClient())
            {
                string text = await wc.DownloadStringTaskAsync("http://localhost/UMT_Minecraft_Cracked/Sign_Out_Count.txt");
                text = text.Trim();

                if (int.TryParse(text, out int newSignOutCount))
                {
                    if (lastSignOutCount == -1)
                    {
                        lastSignOutCount = newSignOutCount;
                        return;
                    }

                    if (newSignOutCount == lastSignOutCount + 1)
                    {
                        // Reset
                        buttonsLoaded = false;
                        lastSignOutCount = newSignOutCount;

                        converterOptionButton.Visible = false;
                        prunerOptionButton.Visible = false;
                        nbtOptionButton.Visible = false;
                    }
                }
            }
        }
        catch { }
    }

    void LoadImages()
    {
        nbtNormal = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/NBT_Editor.png");
        nbtHover = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/NBT_Editor_h.png");

        converterNormal = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Converter.png");
        converterHover = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Converter_h.png");

        prunerNormal = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Pruner.png");
        prunerHover = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Pruner_h.png");

        extensionsNormal = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Extensions.png");
        extensionsHover = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Extensions_h.png");

        settingsNormal = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Settings.png");
        settingsHover = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Settings_h.png");

        signOutNormal = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/SignOut.png");
        signOutHover = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/SignOut_h.png");

        noButtonImg = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/No_Button.png");

        minimizeNormal = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Minimize.png");
        minimizeHover = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Minimize_h.png");
        minimizeClick = minimizeNormal;

        // Converter
        converterOptionNormal = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Converter_Options/Convertor.png");
        converterOptionHover = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Converter_Options/Convertor_h.png");
        converterTextImage = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Converter_Options/Convertor_Text.png");

        // Pruner
        prunerOptionNormal = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Converter_Options/Pruner.png");
        prunerOptionHover = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Converter_Options/Pruner_h.png");
        prunerTextImage = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Converter_Options/Pruner_Text.png");

        // NBT
        nbtOptionNormal = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Converter_Options/NBT_Editor.png");
        nbtOptionHover = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Converter_Options/NBT_Editor_h.png");
        nbtTextImage = LoadImage("https://raw.githubusercontent.com/NewAgent2025/NewAgentsSite/refs/heads/main/UMT_Images_Buttons/Converter_Options/NBT_Text.png");
    }

    void SetupButton(PictureBox btn, Image normal, Image hover, int w, int h)
    {
        btn.Size = new Size(w, h);
        btn.SizeMode = PictureBoxSizeMode.StretchImage;
        btn.Image = normal;

        btn.MouseEnter += (s, e) => btn.Image = hover;
        btn.MouseLeave += (s, e) => btn.Image = normal;

        Controls.Add(btn);
    }

    void SetupConverterOptionButton()
    {
        converterOptionButton.Size = new Size(192, 192);
        converterOptionButton.SizeMode = PictureBoxSizeMode.StretchImage;
        converterOptionButton.Image = converterOptionNormal;
        converterOptionButton.Location = new Point(404, 264);
        converterOptionButton.Visible = false;

        converterOptionButton.MouseEnter += (s, e) =>
        {
            converterOptionButton.Image = converterOptionHover;
            converterHoverText.Visible = true;
        };
        converterOptionButton.MouseLeave += (s, e) =>
        {
            converterOptionButton.Image = converterOptionNormal;
            converterHoverText.Visible = false;
        };

        Controls.Add(converterOptionButton);
    }

    void SetupConverterHoverText()
    {
        converterHoverText.Size = new Size(446, 12);
        converterHoverText.SizeMode = PictureBoxSizeMode.StretchImage;
        converterHoverText.Image = converterTextImage;
        converterHoverText.Location = new Point(277, 502);
        converterHoverText.Visible = false;
        Controls.Add(converterHoverText);
    }

    void SetupPrunerOptionButton()
    {
        prunerOptionButton.Size = new Size(192, 192);
        prunerOptionButton.SizeMode = PictureBoxSizeMode.StretchImage;
        prunerOptionButton.Image = prunerOptionNormal;
        prunerOptionButton.Location = new Point(616, 264);
        prunerOptionButton.Visible = false;

        prunerOptionButton.MouseEnter += (s, e) =>
        {
            prunerOptionButton.Image = prunerOptionHover;
            prunerHoverText.Visible = true;
        };
        prunerOptionButton.MouseLeave += (s, e) =>
        {
            prunerOptionButton.Image = prunerOptionNormal;
            prunerHoverText.Visible = false;
        };

        Controls.Add(prunerOptionButton);
    }

    void SetupPrunerHoverText()
    {
        prunerHoverText.Size = new Size(389, 11);
        prunerHoverText.SizeMode = PictureBoxSizeMode.StretchImage;
        prunerHoverText.Image = prunerTextImage;
        prunerHoverText.Location = new Point(305, 502);
        prunerHoverText.Visible = false;
        Controls.Add(prunerHoverText);
    }

    void SetupNBTOptionButton()
    {
        nbtOptionButton.Size = new Size(192, 192);
        nbtOptionButton.SizeMode = PictureBoxSizeMode.StretchImage;
        nbtOptionButton.Image = nbtOptionNormal;
        nbtOptionButton.Location = new Point(192, 264);
        nbtOptionButton.Visible = false;

        nbtOptionButton.MouseEnter += (s, e) =>
        {
            nbtOptionButton.Image = nbtOptionHover;
            nbtHoverText.Visible = true;
        };
        nbtOptionButton.MouseLeave += (s, e) =>
        {
            nbtOptionButton.Image = nbtOptionNormal;
            nbtHoverText.Visible = false;
        };

        Controls.Add(nbtOptionButton);
    }

    void SetupNBTHoverText()
    {
        nbtHoverText.Size = new Size(491, 11);
        nbtHoverText.SizeMode = PictureBoxSizeMode.StretchImage;
        nbtHoverText.Image = nbtTextImage;
        nbtHoverText.Location = new Point(254, 502);
        nbtHoverText.Visible = false;
        Controls.Add(nbtHoverText);
    }

    void SetupNoButton()
    {
        noButton.Size = new Size(38, 37);
        noButton.SizeMode = PictureBoxSizeMode.StretchImage;
        noButton.Image = noButtonImg;
        Controls.Add(noButton);
    }

    void SetupMinimizeButton()
    {
        minimizeButton.Size = new Size(38, 37);
        minimizeButton.SizeMode = PictureBoxSizeMode.StretchImage;
        minimizeButton.Image = minimizeNormal;

        minimizeButton.MouseEnter += (s, e) => minimizeButton.Image = minimizeHover;
        minimizeButton.MouseLeave += (s, e) => minimizeButton.Image = minimizeNormal;
        minimizeButton.MouseUp += (s, e) => ShowWindow(targetProcess.MainWindowHandle, SW_MINIMIZE);

        Controls.Add(minimizeButton);
    }

    Image LoadImage(string url)
    {
        using (var wc = new WebClient())
        {
            byte[] bytes = wc.DownloadData(url);
            using (var ms = new System.IO.MemoryStream(bytes))
            {
                return Image.FromStream(ms);
            }
        }
    }

    void TrackPosition(object sender, EventArgs e)
    {
        if (targetProcess == null || targetProcess.HasExited)
        {
            Close();
            return;
        }

        if (GetWindowRect(targetProcess.MainWindowHandle, out RECT rect))
        {
            nbtButton.Location = new Point(LEFT_X, NBT_Y);
            converterButton.Location = new Point(LEFT_X, CONVERTER_Y);
            prunerButton.Location = new Point(LEFT_X, PRUNER_Y);
            extensionsButton.Location = new Point(LEFT_X, EXTENSIONS_Y);
            settingsButton.Location = new Point(LEFT_X, SETTINGS_Y);
            signOutButton.Location = new Point(LEFT_X, SIGNOUT_Y);

            converterOptionButton.Location = new Point(404, 264);
            converterHoverText.Location = new Point(277, 502);

            prunerOptionButton.Location = new Point(616, 264);
            prunerHoverText.Location = new Point(305, 502);

            nbtOptionButton.Location = new Point(192, 264);
            nbtHoverText.Location = new Point(254, 502);

            noButton.Location = new Point(NO_BUTTON_X, 0);
            minimizeButton.Location = new Point(MINIMIZE_X, 0);

            this.Location = new Point(0, 0);
            this.Size = new Size(1000, SIGNOUT_Y + 64);
        }
    }
}

class Program
{
    [STAThread]
    static void Main()
    {
        string processName = "UMT_Cracked";

        Process[] processes = Process.GetProcessesByName(processName);

        if (processes.Length == 0)
        {
            MessageBox.Show("UMT_Cracked.exe is NOT running.");
            return;
        }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new OverlayForm(processes[0]));
    }
}